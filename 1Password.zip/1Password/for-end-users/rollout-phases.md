---
title: "1Password: Rollout Phases"
description: "1Password rollout phases and support information."
diataxis-type: reference
tags:
  - 1password
---

# 1Password Rollout Phases

!!! abstract "Deployment Overview"
 1Password Enterprise will be deployed in strategic phases across Volvo Cars, organized by business units to ensure smooth implementation and optimal user experience.

---

## Rollout Information

!!! info "Phased Deployment Strategy"
 The 1Password rollout follows a carefully planned approach, ensuring each business unit receives proper support and training during their implementation phase.

### Support and Updates

**Latest Updates:**
For the most current rollout information and timelines, visit the  **[Rollout Phases Portal](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Rollout-Phases.aspx?csf=1&web=1&e=HH51ai&CID=06b6a7e0-2d91-44a8-b861-16955f352128)**

**Support Requests:**
For any questions or assistance from the 1Password Team, submit a **[ServiceNow Request](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=9db1af9f3b8cfa58b179dd24c3e45acd&table=sc_cat_item&searchTerm=1password)**

**Direct Contact:**
Email support: [`cld-1Password_Enterprise@grp.volvocars.com`](mailto:cld-1Password_Enterprise@grp.volvocars.com)

---

## Deployment Phases

!!! tip "Phase-Based Implementation"
 Each phase targets specific business units to ensure manageable deployment and dedicated support during the rollout process.

### Rollout Schedule Overview

| Phase | Business Units |
|-------|---------------|
| **Phase 1**| Platform & Strategy Users |
| **Phase 2**| Engineering & Engineering Operations Users |
| **Phase 3**| Manufacturing & Supply Chain Users |
| **Phase 4**| Commercial & Commercial Operations Users |
| **Phase 5**| People Experience Users<br/>Group Legal & Corporate Governance Users<br/>Finance & Performance Steering Users<br/>Design & UX Users<br/>Communication Users |
| **Phase 6**| All Other Users |

---

## Getting Help

!!! example "Support Resources"
 Need assistance or have questions about your rollout phase? Use these resources for comprehensive support.

### Support Channels

**Check Your Phase Status:**
Visit the **[Rollout Phases Portal](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Rollout-Phases.aspx?csf=1&web=1&e=HH51ai&CID=06b6a7e0-2d91-44a8-b861-16955f352128)** for real-time updates

**Submit Support Request:**
Create a **[ServiceNow Request](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=9db1af9f3b8cfa58b179dd24c3e45acd&table=sc_cat_item&searchTerm=1password)** for technical assistance

**Email Support:**
Contact [` cld-1Password_Enterprise@grp.volvocars.com`](mailto:cld-1Password_Enterprise@grp.volvocars.com) for direct support

**Comprehensive FAQ:**
Browse our **[FAQ Guide](../faq.md)** for answers to common questions

---

!!! success "Ready to Get Started?"
 Once your phase is active, check out our **[Getting Started Guide](../introduction.md)** for step-by-step setup instructions!

:::related-docs:::
