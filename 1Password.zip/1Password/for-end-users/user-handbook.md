---
title: "1Password: User Handbook"
description: "Instructions for setting up and using 1Password on different device types."
diataxis-type: how-to
tags:
  - 1password
  - secrets
---

# 1Password User Handbook

## Setup Guide by User Type

### Managed Device Users

A managed device user accesses Volvo Cars resources and applications using a Volvo Cars managed laptop or mobile device. The 1Password application will be auto-deployed and available on your managed devices to enable setup.

**Setup Instructions:**
[1Password Setup for Managed Device Users](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Non-VDI.aspx?csf=1&web=1&e=5QFeoI&CID=0fa3b471-f2f1-4625-a7f4-104b721c2cfa)

---

### Virtual Desktop Users

A Virtual Desktop user accesses Volvo Cars resources and applications using a Volvo Cars managed Azure Virtual Desktop instance. VDI users do not possess any Volvo Cars managed laptops or mobile devices.

**Web Portal Access:** https://volvocars.1password.eu

**Setup Instructions:**
[1Password Setup for VDI Users](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/VDI.aspx?csf=1&web=1&e=WU3qLl&CID=2a301231-9b69-4a89-88ea-335895e9eb1a)

---

### Web Portal Users

1Password provides a web portal for accessing your employee and team vaults. Users who do not have managed devices or virtual desktops assigned can use the 1Password web portal for storing and managing their Volvo Cars credentials.

**Web Portal Access:** https://volvocars.1password.eu

**Setup Instructions:**
[1Password Setup for Web Portal Users](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Web-Portal-Users.aspx?csf=1&web=1&e=t1YBb1&CID=d701fe89-831e-4434e-9241-887ccd6e8dcb)

---

## Support and Resources

**For Technical Support:**
[Contact Support Team](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Contact-Us.aspx)

**Additional Resources:**

  - [Frequently Asked Questions](../faq.md).

  - [Team Vaults Management](./team-vaults.md).

  - [1Password onboarding](../faq.md#how-do-i-get-1password).

:::related-docs:::
