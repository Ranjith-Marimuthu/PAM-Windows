---
title: "1Password: Technical Setup"
description: "1Password technical setup, incident management, support, and service levels."
diataxis-type: reference
tags:
  - 1password
  - secrets
---

# 1Password Technical Setup

!!! abstract "Technical Support Overview"
 Comprehensive technical setup documentation covering incident management, support procedures, and service level agreements for 1Password Enterprise at Volvo Cars.

---

## Incident Management

!!! danger "Emergency Response Protocol"
 All incidents must follow the standard VCC incident management process and align with global priority definitions for consistent response and resolution.

### Priority Levels

**P1 - Critical Service Outage**

- **Impact**: Complete 1Password outage affecting all users
- **Symptoms**: Unable to access any vaults or credentials across all devices
- **Resolution Target**: 24/7 support with immediate response
- **Resolver**: 1Password Enterprise Support Team

**P2 - Major Service Disruption**

- **Impact**: Service partially available, affecting 50+ users
- **Symptoms**: Login failures, account access issues, or sync problems
- **Resolution Target**: 24/7 support with prioritized response
- **Resolver**: 1Password Enterprise Support Team

---

## Support Contacts

!!! info "ServiceNow Portal Access"
 **Primary Support Portal:** [1Password Support](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=9db1af9f3b8cfa58b179dd24c3e45acd&table=sc_cat_item&searchTerm=1password)

### Support Team Structure

| Role | Name | Contact | Availability |
|------|------|---------|-------------|
| **Primary Support** | Tyno Ravindran | (+46) 722037193<br> tyno.raveendran@volvocars.com | 24×7 |
| **Secondary Support** | Subham Debnath | (+91) 7980737871<br> subham.debnath@volvocars.com | 24×7 |
| **Escalation (L1)** | Varun Golani | (+46) 764318552<br> varun.golani@volvocars.com | 24×7 |
| **Escalation (L2)** | Aditya Kucharlapati | (+91) 9920726966<br> aditya.kucharlapati@volvocars.com | 24×7 |
| **Escalation (L2)** | Sunil V Palayyan | (+46) 702226236<br> sunil.kumar.vimala.palayyan@volvocars.com | 24×7 |

---

## Service Level Agreements

!!! success "Comprehensive Support Coverage"
 Differentiated support levels based on service criticality and business impact.

- **Core Application**: 24/7 support with immediate response
- **Peripheral Services**: 9/5 support (business hours)

---

## Service Request Procedures

!!! tip "ServiceNow Integration"
 All 1Password requests are handled through the ServiceNow portal for consistent tracking and resolution.

### General Support

For general 1Password support, technical assistance, and troubleshooting:

!!! example "Support Request Portal"
 **[1Password Support](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=9db1af9f3b8cfa58b179dd24c3e45acd&table=sc_cat_item&searchTerm=1password)**

### Team Vault Requests

To request a new team vault or remove an existing one:

!!! example "Vault Management Portal"
 **[1Password Create/Remove Team Vault Request](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=2c6eaa5033d8fe58a02005a9ed5c7baa&table=sc_cat_item&searchTerm=1password)**

**Required Information:**

- Action required (Add/Remove vault)
- Team vault owner
- Vault name
- Application ID
- Business justification

### Account Recovery

For account recovery assistance and emergency access:

!!! example "Recovery Request Portal"
 **[1Password Account Recovery Requests](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=7f265f9f3b48fa58b179dd24c3e45a61&table=sc_cat_item&searchTtml=1password)**

**Required Information:**

- Affected user details
- Contact information
- Employee ID or username
- Last known access date

:::related-docs:::
