---
title: "1Password: FAQ"
description: "Frequently asked questions about 1Password onboarding, security, and support."
diataxis-type: reference
tags:
  - 1password
  - secrets
---

# 1Password Frequently Asked Questions

!!! abstract "FAQ Overview"
 Comprehensive answers to common questions about 1Password Enterprise at Volvo Cars, covering onboarding, security features, troubleshooting, and account management.

---

## Getting Started

### How do I get 1Password?

!!! info "Phased Rollout Process"
 1Password will be rolled out in phases to all users in Volvo Cars. If you are part of a rollout phase, you will receive a welcome email from Digital Identity ([digiid@volvocars.com](mailto:digiid@volvocars.com)).

**Onboarding Process:**

1. **Accept the 1Password joining email**- Check your Volvo Cars mailbox for an email from [`accounts@custommail.1password.eu`](mailto:accounts@custommail.1password.eu)
2. **Setup your 1Password desktop application**- Automatic installation on managed devices
3. **Setup your 1Password mobile application**- Deployed via MDM
4. **Setup your browser extension***(Optional)* - Enhanced web experience
5. **Start storing credentials**- Use your dedicated Employee Vault

!!! tip "Rollout Information"
 **[View Rollout Phases](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Rollout-Phases.aspx?csf=1&web=1&e=MLvoPc&CID=0bf3a6ea-bb8b-4fb8-b872-fd749d094900)**- Check your rollout phase and timeline

### How do I get the 1Password desktop app and mobile app?

!!! success "Automatic Installation"
 The 1Password desktop application and mobile application will be auto-installed on your Volvo Cars managed devices during the rollout phase. No manual action required!

**Installation Details:**

 **Desktop Applications:** All desktop apps are automatically deployed through the Software Center on your managed devices, ensuring consistent installation across the organization.

 **Mobile Applications:** Mobile apps are seamlessly deployed via Mobile Device Management (MDM), providing secure and centralized distribution to your devices.

 **Automatic Updates:** All application updates are managed automatically by the IT department, ensuring you always have the latest features and security patches.

---

## Support & Troubleshooting

### Who do I contact in case of errors or issues with 1Password?

!!! warning "24/7 Support Available"
 For all issues, errors and queries, your single point of contact is the dedicated 1Password Enterprise support team.

**Primary Support Contact:**

- **Email:** [`cld-1Password_Enterprise@grp.volvocars.com`](mailto:cld-1Password_Enterprise@grp.volvocars.com)
- **Availability:** 24×7 monitoring
- **Response Time:** Prioritized based on issue severity

### Who do I contact if my 1Password desktop app or mobile app is missing?

!!! info "Application Support"
 For missing applications or installation issues, contact the same dedicated support team.

**Support Contact:**
- **Email:** [`cld-1Password_Enterprise@grp.volvocars.com`](mailto:cld-1Password_Enterprise@grp.volvocars.com)
- **Coverage:** Desktop apps, mobile apps, browser extensions
- **Availability:** 24×7 monitoring

---

## Browser Integration

### How do I enable form-fill on my browser for my credentials?

!!! tip "Automatic Form-Fill"
 Form-Fill is enabled by default when using a 1Password browser extension. Simply save your credentials when prompted.

**Form-Fill Process:**
1. **Navigate** to a login page
2. **Enter credentials** manually (first time)
3. **Click "Save in 1Password"** when prompted
4. **Auto-fill** on subsequent visits

<div style="text-align: center; margin: 20px 0;">
 <img src="../../1Password/Images/content.png" 
 alt="1Password Form-Fill Example" 
 style="max-width: 100%; height: auto; border: 2px solid #e1e5e9; border-radius: 8px;">
</div>

### Do I need to save my credentials separately on the desktop app and browser plugin?

!!! success "Automatic Synchronization"
 No separate saving required! Sync is automatically enabled across all your devices and applications.

**Sync Features:**

 **Desktop to Browser:** Credentials saved on your desktop automatically sync to browser extensions, ensuring seamless access across applications.

 **Browser to Desktop:** Any credentials saved through browser extensions immediately appear in your desktop application for unified management.

 **Cross-Platform Availability:** Your vault synchronizes across mobile apps, desktop applications, and the web portal, providing consistent access everywhere.

 **Real-Time Synchronization:** Changes made on any device sync instantly across all your connected devices and applications.

---

## Security Features

### How do I know if my passwords are strong or weak?

!!! info "Automatic Password Analysis"
 1Password automatically analyzes password strength when you save credentials. This feature works consistently across desktop app, mobile app, and browser plugins.

**Password Strength Indicators:**

 **Strong Passwords:** Green indicators clearly mark secure passwords that meet security best practices and provide excellent protection for your accounts.

 **Weak Passwords:** Yellow or orange warnings alert you to vulnerable passwords that should be strengthened to improve your security posture.

 **Compromised Passwords:** Red alerts immediately notify you of passwords that have been found in data breaches and require immediate attention.

 **Duplicate Passwords:** Automated notifications identify reused passwords across multiple accounts, helping you maintain unique credentials for each service.

**Example: Weak Password Warning**

<div style="text-align: center; margin: 20px 0;">
 <img src="../../1Password/Images/weak.png" 
 alt="Weak Password Warning Example" 
 style="max-width: 100%; height: auto; border: 2px solid #e1e5e9; border-radius: 8px;">
</div>

### What is Watchtower?

!!! success "Security Command Center"
 Watchtower serves as your security HQ, automatically analyzing and summarizing your stored credential strengths with comprehensive security monitoring.

**Watchtower Features:**

 **Breach Detection:** Seamlessly integrates with [Have I Been Pwned](https://haveibeenpwned.com/) to continuously monitor and identify compromised passwords in your vault.

 **Strength Analysis:** Automatically flags weak or duplicate passwords, providing real-time feedback to help you maintain strong, unique credentials across all accounts.

 **2FA Recommendations:** Intelligently identifies websites where you can enable two-factor authentication, enhancing your security with an additional layer of protection.

**Privacy-First Security:** All security checks happen locally on your device, ensuring your sensitive data never leaves your control during the analysis process.

 **Security Score:** Provides a comprehensive overall security posture assessment, giving you clear visibility into your credential security health.

**Access Watchtower:**

 **Desktop Application:** Simply click "Watchtower" in the sidebar of your desktop application to access comprehensive security monitoring and analysis tools.

 **Web Portal:**Watchtower is conveniently available in the main navigation of the web portal, providing the same security insights from any browser.

<div style="text-align: center; margin: 20px 0;">
 <img src="../../1Password/Images/watchtover.png" 
 alt="Watchtower Dashboard Example" 
 style="max-width: 100%; height: auto; border: 2px solid #e1e5e9; border-radius: 8px;">
</div>

!!! tip "Learn More"
 **[Official Watchtower Documentation](https://support.1password.com/watchtower/?windows)**- Comprehensive guide to Watchtower features
### How does Watchtower help?

!!! info "Comprehensive Security Dashboard"
 The Watchtower dashboard provides a complete overview of your credential security with actionable insights and remediation guidance.

**Security Monitoring Categories:**

 **Password Strength Analysis:** Systematically identifies weak passwords that require updates, helping you maintain robust security across all your accounts.

 **Vulnerable Password Detection:** Actively highlights compromised credentials from known data breaches, enabling immediate action to protect your accounts.

 **Duplicate Password Detection:** Efficiently finds reused passwords across multiple accounts, encouraging unique credential creation for enhanced security.

 **2FA Enhancement Opportunities:** Proactively suggests websites where you can enable two-factor authentication to add an extra layer of account protection.

 **Comprehensive Security Scoring:** Provides an overall security rating for all your stored credentials, giving you clear insight into your security posture.

**Strong Security Posture Example:**

<div style="text-align: center; margin: 20px 0;">
 <img src="../../1Password/Images/watchtower1.png" 
 alt="Watchtower - Strong Security Dashboard" 
 style="max-width: 100%; height: auto; border: 2px solid #e1e5e9; border-radius: 8px;">
 <p style="font-style: italic; color: #666; margin-top: 10px;">
 <strong>Strong Credentials:</strong> Healthy Watchtower dashboard showing good security posture
 </p>
</div>

**Security Issues Detected Example:**

<div style="text-align: center; margin: 20px 0;">
 <img src="../../1Password/Images/watchtower2.png" 
 alt="Watchtower - Security Issues Dashboard" 
 style="max-width: 100%; height: auto; border: 2px solid #e1e5e9; border-radius: 8px;">
 <p style="font-style: italic; color: #666; margin-top: 10px;">
 <strong>Action Required:</strong> Dashboard showing vulnerable credentials requiring attention
 </p>
</div>

!!! warning "Remediation Actions"
 When Watchtower identifies security issues, take immediate action by updating weak credentials with strong, unique passwords for each account.

---

## Advanced Watchtower Configuration

### How to check for breached passwords using Watchtower in the 1Password Desktop Application?

!!! tip "Desktop Configuration"
 Enable advanced Watchtower settings in your desktop application to activate breach monitoring capabilities.

**Configuration Steps:**

1. **Open Application** - Launch the 1Password Desktop Application on your device
2. **Access Settings** - Navigate to Settings/Preferences from the main menu
3. **Enable Monitoring** - Enable advanced Watchtower monitoring capabilities
4. **Configure Detection** - Configure breach detection settings according to your security preferences

!!! example "Detailed Guide"
 **[Desktop Watchtower Setup](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Watchtower%20Desktop.aspx?CID=3fdc2394-49a7-420a-8365-bf8eead294a9)**- Step-by-step configuration instructions

### How to check for breached passwords using Watchtower in the 1Password Browser Plugin?

!!! tip "Browser Extension Configuration"
 Configure your browser extension to enable comprehensive breach monitoring and security analysis.

**Browser Setup:**

1. **Access Extension** - Click the 1Password browser extension icon in your browser toolbar
2. **Open Settings** - Access extension settings from the dropdown menu
3. **Enable Security** - Enable Watchtower security features for comprehensive monitoring
4. **Configure Monitoring** - Configure breach monitoring preferences to suit your security needs

!!! example "Detailed Guide"
 **[Browser Plugin Watchtower Setup](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Watchtower%20Browser%20Plugin.aspx?CID=2822240a-fde7-4cea-89c4-f48cb704891b)** - Complete browser configuration guide

### How to check for breached passwords using Watchtower in the 1Password Web Portal?

!!! tip "Web Portal Configuration"
 Enable advanced security monitoring through the 1Password web interface for comprehensive breach detection.

**Web Portal Setup:**

1. **Portal Access** - Log in to the 1Password web portal using your Volvo Cars credentials
2. **Security Navigation** - Navigate to security settings from the main dashboard
3. **Enable Watchtower** - Enable Watchtower features for comprehensive security monitoring
4. **Configure Preferences** - Configure monitoring preferences based on your organizational requirements

!!! example "Detailed Guide"
 **[Web Portal Watchtower Setup](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Watchtower%20Web%20Portal.aspx?CID=7067cfd8-42b9-4f4f-b589-74d5cec2ce30)**- Web interface configuration instructions

---

## Account Management

### Can I reset my credentials on 1Password?

!!! warning "Password Reset Limitation"
 Password reset cannot be performed for your `CDSID@volvocars.com` account using 1Password. Use the official Volvo Cars self-service portal instead.

**Password Reset Process:**

1. **Visit Self-Service Portal** - Go to [https://aka.ms/sspr](https://aka.ms/sspr)
2. **Reset Volvo Cars Credentials** - Follow the standard VCC password reset process
3. **Update 1Password** - Once reset is complete:
 - Open the saved credential in your 1Password Employee Vault
 - Update it with the new password value
 - Save the updated credential

!!! tip "Keep Credentials Synchronized"
 Always update your 1Password vault items after changing passwords through official channels to maintain accuracy.

### Is MFA enabled for my 1Password account?

!!! success "Default MFA Protection"
 MFA is enabled by default for your 1Password account through integration with your Volvo Cars identity.

**MFA Integration Details:**

 **Seamless Account Linking:** Your 1Password account is securely tied to your `CDSID@volvocars.com` account, providing unified authentication across Volvo Cars systems.

 **Existing Method Compatibility:** All your current MFA registrations (SMS, Authenticator app, hardware tokens, etc.) automatically apply to 1Password access, eliminating setup complexity.

 **Consistent User Experience:** The same trusted MFA methods work seamlessly across desktop applications and browser plugins, ensuring familiar and reliable authentication.

 **Corporate-Grade Security:** Enhanced with enterprise-level multi-factor authentication protection that meets Volvo Cars' stringent security requirements.

### How do I recover my 1Password account?

!!! info "Account Recovery Process"
 Since your 1Password account is tied to your Volvo Cars account, offboarding or disabling your Volvo Cars ID will result in suspension of your 1Password account.

**Recovery Process:**

1. **Submit ServiceNow Request** - Use the official recovery portal
2. **Provide Required Information** - Include all necessary account details
3. **Wait for Processing** - Support team will process your request
4. **Account Restoration** - Access will be restored once approved

!!! example "Account Recovery Portal"
 **[1Password Account Recovery](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=7f265f9f3b48fa58b179dd24c3e45a61&table=sc_cat_item&searchTerm=1password)**- Submit your recovery request through ServiceNow

### Do I need to setup my Employee Vault again after recovery?

!!! success "Automatic Restoration"
 No setup required! Your Employee Vault and all stored credentials will be automatically restored after account recovery.

**What Gets Restored:**

 **Employee Vault:** All your personal credentials and items are completely restored, maintaining the exact same organization and structure as before suspension.

**Team Vault Access:** Your access to shared team vaults is automatically reinstated, allowing immediate collaboration with your colleagues and teams.

 **Device Connections:** All previous device registrations are restored, so your desktop, mobile, and browser applications reconnect seamlessly without reconfiguration.

 **Settings & Preferences:** Your personalized configurations, including preferences, themes, and custom settings, return exactly as you had configured them.

 **Watchtower Security Data:** Security monitoring continues seamlessly with all previous breach monitoring, security scores, and analysis data intact.

!!! tip "Zero Data Loss"
 The recovery process maintains complete data integrity - everything returns exactly as it was before suspension.

---

## Data Migration

### How do I import all my other Volvo Cars credentials from other applications and browsers to my Employee Vault?

!!! info "Comprehensive Import Support"
 1Password supports importing credentials from virtually all major password managers and browsers, making migration seamless and comprehensive.

**Supported Browsers:**

**Chrome:** Direct import from saved passwords with full synchronization support for Google accounts and stored credentials.

**Firefox:** Complete credential migration including bookmarks, saved passwords, and browser-specific security settings.

 **Microsoft Edge:** Seamless transfer process that maintains all saved passwords and autofill data from your Edge browser.

**Brave:** Full compatibility support for privacy-focused users, including secure credential transfer and sync capabilities.

**Safari:** Native macOS integration available with complete credential import from Keychain and Safari password manager.

**Supported Password Managers:**

**Dashlane:** Complete vault migration with full preservation of folder structures, secure notes, and payment information.

 **KeePass/KeePassX:** Advanced database import functionality that maintains all custom fields, attachments, and organizational hierarchies.

**LastPass:** Direct migration tools specifically designed to transfer all vault items, shared folders, and security settings seamlessly.

**RoboForm:** Full credential transfer including form-fill data, identity information, and bookmark synchronization.

**Delinea Secret Server:** Enterprise-grade import capabilities designed for large-scale organizational credential migrations.

**Additional Import Options:**

 **CSV Format Support:** Import credentials from any application that exports CSV files, providing universal compatibility with virtually any password management system.

 **Custom Format Compatibility:** Advanced support for various proprietary formats ensures successful migration from specialized or legacy password management solutions.

 **Bulk Import Capabilities:** Efficiently handle large credential databases with batch processing that maintains data integrity across thousands of entries.

!!! example "Import Instructions"
 **[Complete Import Guide](https://support.1password.com/import/?windows)** - Step-by-step instructions for transferring from other password managers, applications, and browsers

---

## Family Account Benefits

### How do I link and unlink my family account?

!!! success "Free Family Account Benefit"
 Volvo Cars provides a complimentary family account to all 1Password Enterprise users for personal use.

**Important Registration Note:**

 **Use Personal Email:** Always register your family account with your personal email address to ensure continued access even after employment changes.

 **Avoid Corporate Email:** Do not use your Volvo Cars email address for family accounts, as this may cause access issues when your corporate account status changes.

**Account Management:**

!!! example "Link Family Account"
 **[Link Your Family Account](https://support.1password.com/link-family/)** - Connect your personal 1Password family subscription

!!! example "Unlink Family Account"
 **[Unlink Your Family Account](https://support.1password.com/unlink-family/)** - Disconnect your family account if needed

### How long is my family account valid?

!!! info "Family Account Duration"
 Your family account validity is tied to your Volvo Cars 1Password Enterprise subscription status.

**Account Timeline:**

 **Active Period:** Your family account remains fully active and accessible as long as your Volvo Cars 1Password Enterprise account is active and in good standing.

**Grace Period:** After Volvo Cars account offboarding, you receive a generous 14-day free extension to ensure uninterrupted access during your transition period.

**Continuation Option:** You can seamlessly add a payment method to continue using your family account independently after the grace period expires, maintaining all your personal data.

---

## Vault Management

### Can I create new vaults apart from Employee Vault?

!!! tip "Additional Vault Requests"
 New vault creation requires approval through the ServiceNow request process for proper governance and security.

**Vault Request Process:**

1. **Submit Request:** Access the ServiceNow portal and complete the vault creation request form with all required information and organizational details.

2. **Provide Justification:** Clearly explain the business need for the additional vault, including how it will improve security, collaboration, or operational efficiency.

3. **Specify Access Requirements:** Define exactly who needs access to the new vault, including team members, roles, and permission levels required for proper governance.

4. **Wait for Security Approval:** The security team will thoroughly review your request against company policies and approve it based on compliance and security requirements.

!!! example "Vault Request Portal"
 **[Create/Remove Team Vault Request](https://volvocars.service-now.com/sp?id=sc_cat_item&sys_id=2c6eaa5033d8fe58a02005a9ed5c7baa&table=sc_cat_item&searchTerm=1password)** - Submit your vault creation or removal request through ServiceNow

:::related-docs:::
