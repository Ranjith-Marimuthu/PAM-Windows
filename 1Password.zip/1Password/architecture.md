---
title: "1Password: Architecture"
description: "1Password Enterprise architecture, integrations, and authentication flows."
diataxis-type: explanation
tags:
  - 1password
  - secrets
  - integration
  - authentication
---

# 1Password Architecture

!!! abstract "Document Overview"
 This document outlines the comprehensive architecture and integration points of the 1Password Enterprise password manager within the Volvo Cars environment, including security monitoring, authentication flows, and deployment strategies.

---

## High-Level Architecture

The overall 1Password architecture consists of the following key components:

<div style="text-align: center; margin: 20px 0;">
    <img src="../../1Password/Images/1PasswordArc.png" 
         alt="1Password Architecture Diagram" 
         style="max-width: 100%; height: auto; border: 2px solid #e1e5e9; border-radius: 12px; box-shadow: 0 6px 16px rgba(0,0,0,0.15);">
    <p style="font-style: italic; color: #666; margin-top: 10px; font-size: 0.9em;">
        <strong>Figure 1:</strong> 1Password Enterprise Architecture at Volvo Cars
    </p>
</div>

---

## System Architecture

!!! info "Architecture Overview"
 The 1Password implementation at Volvo Cars consists of several interconnected components as shown in the high-level architecture diagram above. Each component serves a specific role in the overall security and operational framework.

### Component Descriptions

**1Password EPM [Azure App]**

- Enterprise Password Manager application registered in Azure
- Used for SAML/OIDC federation with 1Password Enterprise service
- Manages authentication and permissions
- Integrated with VCC Entra ID for seamless SSO

**1Password Enterprise [Service]**

- Cloud-based password management service
- Stores and manages all credentials and vaults
- Provides web, desktop, and mobile interfaces
- Managed by 1Password (AgileBits Inc.)
- Enterprise-grade security and compliance

**Entra ID [Identity Provider]**

- Primary identity provider for Volvo Cars
- Handles user authentication for 1Password
- Manages group-based access control
- Enables SSO for 1Password
- Centralized identity management

**1Password Clients [Applications]**

- Desktop applications (Windows, macOS)
- Mobile applications (iOS, Android)
- Browser extensions
- CLI tools (restricted to 1Password administrators only)
- Cross-platform compatibility

**1Password SCIM Bridge [Azure Container App]**

- Containerized SCIM bridge deployed in Azure Container Apps
- Handles user provisioning from Entra ID to 1Password
- Translates SCIM protocol requests to 1Password API calls
- Securely stores bearer token for 1Password API authentication
- Auto-scaling and high availability

---

## Authentication Flow

### SSO Authentication Architecture

!!! tip "OIDC Integration"
 The authentication architecture leverages OIDC/OAuth2 protocols with VCC Entra ID serving as the identity provider for 1Password, ensuring secure and seamless user access.

### Authentication Process Flow

1Password at Volvo Cars uses OIDC (OpenID Connect) for authentication as detailed in the main architecture diagram:

1. **User Access Request**- User attempts to access 1Password
2. **SSO Redirect**- 1Password redirects to Entra ID for authentication
3. **Credential Validation**- User authenticates with Entra ID credentials
4. **Token Exchange**- Entra ID returns OIDC token to 1Password
5. **Access Granted**- 1Password grants access based on the validated token

---

## User Provisioning Flow

### User Provisioning Process

!!! info "Automated Lifecycle Management"
 The user provisioning process begins with the HR system and flows through the 1Password Admin Team to Entra ID groups, which then automatically provision user accounts in 1Password through SCIM integration.

### SCIM Provisioning Technical Implementation

1Password at Volvo Cars uses SCIM (System for Cross-domain Identity Management) for automated user provisioning via an Azure Container App deployment:

1. **Account Creation**- User account is created or updated in Entra ID
2. **Change Detection**- Entra ID SCIM connector detects the change
3. **SCIM Request**- SCIM protocol sends user attributes to the 1Password SCIM Bridge deployed in Azure Container App
4. **Request Translation**- The SCIM Bridge translates and forwards the provisioning requests to 1Password
5. **Account Provisioning**- 1Password provisions/updates the user account automatically
6. **Access Control**- Group memberships from Entra ID control vault access in 1Password

---

## Azure Container App Deployment

!!! success "Containerized Infrastructure"
 The 1Password SCIM Bridge is deployed as a containerized application in Azure Container Apps, providing scalable and secure infrastructure for user provisioning operations.

**Deployment Architecture:**

- **Managed Environment**- Kubernetes-based container hosting environment
- **Auto-Scaling**- Dynamic scaling based on traffic demands
- **Fully Managed**- No infrastructure management required (Azure managed)
- **Secure Storage**- Azure Key Vault integration for credential storage
- **Monitoring**- Integrated logging and monitoring via Azure Monitor
- **Deployment**- Manual deployment and configuration via Azure Portal

---

## Integration Points

### 1. Entra ID Integration

!!! info "Identity Provider Integration"
 Seamless integration with VCC Entra ID for authentication and authorization services.

**SSO Authentication**

- Secure single sign-on through Entra ID
- OIDC token-based authentication
- Streamlined user experience with corporate credentials

**Group-Based Access Control**

- Role assignment through Entra ID groups
- Automatic access provisioning based on group membership
- Centralized permission management

**SCIM Provisioning through Azure Container App**

- Automated user lifecycle management (create, update, delete)
- Automated group synchronization
- Role-based access control
- Real-time provisioning updates

---

### 2. Client Deployment

!!! tip "Multi-Platform Distribution"
 Comprehensive deployment strategies across all corporate devices and platforms.

**Software Center Distribution**

- Centralized deployment for Windows endpoints
- Automated installation and updates
- Corporate policy compliance

**MDM Deployment for Mobile Devices**

- Managed deployment to iOS and Android devices
- Configuration profiles for secure setup
- Device compliance enforcement

**CLI Access (Administrators Only)**

- Command-line operations for administrative tasks
- **Not enabled for regular users**
- Restricted to certified 1Password administrators

---

### 3. Administrative Tools

!!! warning "Administrator Access Only"
 These tools are restricted to certified 1Password administrators with appropriate permissions.

**CLI Access (Administrators Only)**

- Secure command line interface for admin operations
- Scriptable actions for bulk operations
- Advanced configuration capabilities

**Administrative API Access**

- REST API for integration with other systems
- Token-based authentication for API calls
- Programmatic management capabilities

**Automation Scripting Capabilities**

- PowerShell and Bash script support
- CI/CD pipeline integration capabilities
- Custom workflow automation

---

### 4. Monitoring & Reporting

!!! success "Comprehensive Security & Analytics Platform"
 Complete visibility into 1Password usage, security posture, and operational metrics with advanced threat detection and password security monitoring.

**Watchtower Security Monitoring**

- **Weak Password Detection**- Continuous monitoring for reused, weak, or compromised passwords
- **Data Breach Monitoring**- Real-time alerts when stored passwords appear in known data breaches
- **Password Health Scoring**- Security strength assessment for all stored credentials
- **Vulnerability Alerts**- Automated notifications for security vulnerabilities in stored items
- **Password Age Tracking**- Monitoring for outdated passwords requiring rotation

**Advanced Security Analytics**

- **Risk Scoring Dashboard**- Comprehensive security posture scoring across all users and vaults
- **Compliance Reporting**- Automated generation of security compliance reports
- **Security Trend Analysis**- Historical analysis of security incidents and improvements

**Usage Analytics & Performance**

- **Integration Health**- Monitoring of SCIM provisioning and SSO performance

**Comprehensive Audit & Activity Logs**

- **Administrative Operations Tracking**- Complete audit trail for all admin actions and changes
- **Item Access Logging**- Tracking of credential access, modifications, and sharing activities
- **SCIM Provisioning Logs**- Comprehensive logging of user lifecycle operations

**Real-time Alerting & Incident Response**

- **Security Incident Alerts**- Immediate notifications for security events requiring attention
- **Policy Violation Notifications**- Real-time alerts when security policies are violated
- **System Health Monitoring**- Proactive alerts for system performance and availability issues

:::related-docs:::
