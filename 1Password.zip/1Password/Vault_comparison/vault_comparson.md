---
title: "1Password: Vault compare"
description: "Comparison of enterprise secrets management tools and their intended uses."
diataxis-type: reference
tags:
  - 1password
  - secrets
  - pam
---

# Enterprise Secrets Management Tools Overview

## 1Password
1Password is primarily a password manager for VCC Internal users. It's designed to be user-friendly and helps employees securely store and manage their daily login and other VCC credentials.

### Where to use 1Password
Use 1Password if you want to store Employee, personal and team passwords securely.

### Types of credentials to be stored in 1Password:
- **Employee vault**: Storing passwords for web applications, SaaS tools, and shared accounts. CDSID and $ accounts and 36accounts.
- **Team vault**: Securely sharing passwords and sensitive information with specific team members or groups.
- **Family Account**: Personal accounts & credentials/secrets can be stored. It will be not monitored and controlled by VCC.

---

## Delinea (PAM)
Delinea, a Privileged Access Management (PAM) solution, is primarily used for IT admins and the Infrastructure team. It is built for controlling, monitoring, and auditing highly sensitive, privileged accounts. It's a comprehensive security platform that goes beyond simple password storage.

### Where to use Delinea Secret Server
Use Delinea Secret Server if you're managing privileged accounts in an enterprise and need audit trails, access control, and compliance.

### Types of credentials to be stored in PAM:
- **Critical Systems/Managing Privileged Accounts**: Securing credentials for administrators, IT staff, and anyone with access to critical systems, such as network devices, servers, and databases.
- **Enforcing Principle of Least Privilege**: Ensuring that users only have the minimum level of access required to perform their jobs, and only for the time they need it (just-in-time access).
- **Session Monitoring and Auditing**: Recording and monitoring all privileged sessions (e.g., SSH, RDP) for compliance and forensic analysis.
- **Automating Credential Rotation**: Automatically changing and rotating passwords for privileged accounts on a regular basis to prevent credential theft.

---

## HashiCorp Vault
HashiCorp Vault is a secrets management tool designed for machine-to-machine interactions, primarily used for DevOps and applications. While it can store static secrets, its power lies in its ability to dynamically generate short-lived credentials for applications and services.

### Where to use HashiCorp Vault
Use HashiCorp Vault if you're a developer or DevOps engineer needing automated secrets management, API access, and fine-grained control.

### Types of credentials to be stored in HashiCorp Vault:
- **Secrets for Applications and Microservices**: Providing temporary, dynamic credentials (like API keys, database usernames/passwords, and TLS certificates) to applications at runtime.
- **Automated Infrastructure**: Securing secrets used by automation tools like Terraform or Kubernetes, ensuring that hard-coded credentials are not stored in code.
- **Encryption as a Service**: Encrypting and decrypting data for applications without the application having to handle the encryption keys directly.
- **Centralized Key Management**: Managing a Public Key Infrastructure (PKI) to issue and revoke certificates for internal systems.

---

## Technical Feature Comparison

| Feature                     | 1Password | Delinea | HashiCorp Vault |
|-----------------------------|-----------|---------|-----------------|
| **Secrets Storage**          | ✅        | ✅      | ✅              |
| **Password Management**      | ✅        | ✅      | ❌              |
| **Privileged Access Management** | ❌     | ✅      | ❌              |
| **Dynamic Secrets**          | ❌        | ⚠️ Limited (rotation only) | ❌              |
| **Encryption-as-a-Service**  | ❌        | ❌      | ✅              |
| **Session Monitoring**       | ❌        | ✅      | ❌              |
| **API Access**               | ✅        | ✅      | ✅              |
| **Kubernetes Integration**   | ❌        | ⚠️ Limited | ✅              |
| **On-Prem Deployment**       | ❌        | ✅      | ✅              |
| **Target Users**             | Employees | IT Admins, Infrastructure | DevOps, Apps |

---

## Technical Feature Explanations

| Feature                      | Explanation |
|------------------------------|-------------|
| **Secrets Storage**           | Ability to securely store sensitive data like passwords, API keys, tokens, etc. |
| **Password Management**       | Tools to manage, share, and rotate passwords across users and teams. |
| **Privileged Access Management (PAM)** | Controls access to high-risk accounts (e.g., admin, root), with monitoring and auditing. |
| **Dynamic Secrets**           | Secrets that are generated on-demand and expire automatically (e.g., DB credentials). |
| **Encryption-as-a-Service**   | Provides APIs to encrypt/decrypt data without managing keys directly. |
| **Session Monitoring**        | Tracks and records user sessions for auditing and compliance. |
| **API Access**                | Ability to integrate with other systems via RESTful APIs for automation. |
| **Kubernetes Integration**    | Native support for managing secrets within Kubernetes clusters. |
| **On-Prem Deployment**        | Can be installed and run on your own infrastructure (not just cloud-based). |

:::related-docs:::
