---
title: "1Password: Introduction"
description: "Introduction to 1Password Enterprise features and usage at Volvo Cars."
diataxis-type: explanation
tags:
  - 1password
  - secrets
---

# 1Password Introduction

Welcome to the comprehensive 1Password documentation for Volvo Cars Digital Trust team. This guide will help you understand, implement, and manage 1Password Enterprise password management solution within our organization.

## What is 1Password?

1Password is a secure, enterprise-grade password manager that helps you store, manage, and auto-fill login credentials across all your devices. It uses advanced encryption to ensure your stored passwords are always safe and integrates with Single Sign-On (SSO) for seamless authentication.

### Core Capabilities

1Password provides the following essential features:

- **Strong Password Generation**: Creates unique, complex passwords for every account
- **Auto-fill Functionality**: Automatically fills credentials for websites and applications 
- **Multi-Device Sync**: Syncs securely across all your registered devices
- **Secure Sharing**: Share passwords safely without using chat or email
- **Team Collaboration**: Provides shared vaults for team-based access

## Key Features

### Personal Security
- **Employee Vaults**: Personal storage for login credentials, secure notes, and sensitive information
- **Password Generator**: Create strong, unique passwords for each account automatically
- **Auto-fill**: Automatically fill login forms on websites and apps (requires browser extension)
- **Watchtower**: Monitor password strength and identify weak, reused, or compromised passwords

### Enterprise Integration 
- **Multi-Device Sync**: Access vaults across VCC managed devices (Windows, macOS, iOS, Android, Linux)
- **Secure Sharing**: Share credentials safely using encrypted links (valid for 1 hour, single-view only)
- **Team Vaults**: Collaborative password storage for teams and departments
- **SSO Integration**: Seamless integration with Volvo Cars Entra ID authentication

## Benefits of 1Password at Volvo Cars

### Security Benefits
- **Secure Storage**: Safely store and organize passwords, secure notes, and sensitive data in personal and team vaults
- **Strong Password Generation**: Automatically generate strong, unique passwords to reduce compromise risk
- **Password Health Monitoring**: Monitor password strength and receive alerts about weak, reused, or breached passwords
- **Encrypted Sharing**: Share credentials using encrypted, time-limited links viewable only once

### Operational Benefits
- **Multi-Platform Access**: Access across all VCC-managed devices (Windows, macOS, iOS, Android)
- **Automated Management**: Integrates with Entra ID for automated access control and user management
- **Auto-fill Capability**: Automatically fill login forms in browsers and applications via 1Password extension
- **Permission Control**: Manage detailed permissions for vault viewing, editing, and administration

## Why Do We Need a Password Manager?

!!! note "The Password Challenge"
 The human brain isn't designed to remember dozens of long, complex, and unique passwords. This leads to:

     Password Reuse : Using the same passwords across multiple accounts
 - **Weak Passwords**: Choosing simple passwords with minor variations
 - **Security Risks**: Weak passwords are among the biggest security threats to organizations

### The Solution

A password manager addresses these challenges by:

1. **Centralized Security**: Securely stores and encrypts all passwords in one place
2. **Unique Password Generation**: Creates strong, unique passwords for every account
3. **Breach Prevention**: Reduces the risk of credential-based attacks
4. **User Experience**: Simplifies login processes while improving security

To enhance security and simplify authentication experiences, Volvo Cars has implemented 1Password Enterprise as our approved password management solution.

## Getting Started

Setting up 1Password is quick and easy. It's available for your company-managed devices (laptops and phones) and virtual desktops (VDIs). 1Password also provides a web portal interface for employee and team vault access.

### Setup Options

Choose your device type below to follow the step-by-step setup instructions:

#### Managed Device Users
For company laptops, phones, and other managed devices.

[**Setup Guide for Managed Devices**](https://intranet.volvocars.net/:u:/r/sites/1PasswordEnterprise/SitePages/Non-VDI.aspx?csf=1&web=1&e=5QFeoI)

#### Virtual Desktop Users 
For Virtual Desktop Infrastructure (VDI) environments.

[**Setup Guide for Virtual Desktops**](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/VDI.aspx?csf=1&web=1&e=WU3qLl&CID=f304063e-78c5-4b7c-b912-837c62c751b3)

#### Web Portal Users
For browser-based access to 1Password.

[**Web Portal Setup Guide**](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Web-Portal-Users.aspx?csf=1&web=1&e=t1YBb1&CID=2a4a0855-7d17-4ca0-bb10-73ea42e0ffef)

## Support and Resources

### Need Help?

Have a question or need assistance with 1Password? Use the resources below to find the right support or browse our FAQ for quick answers.

#### Implementation Information
Learn about rollout phases and implementation timeline.

[**Rollout Phases**](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Rollout-Phases.aspx?csf=1&web=1&e=HH51ai&CID=06b6a7e0-2d91-44a8-b861-16955f352128)

#### Contact Support
Get in touch with our support team for technical assistance.

[**Contact Us**](https://intranet.volvocars.net/sites/1PasswordEnterprise/SitePages/Contact-Us.aspx)

#### Frequently Asked Questions
Browse common questions and solutions.

[**FAQ**](./faq.md)

---

!!! tip "Next Steps"
 Ready to get started? Check out our [Technical Setup Guide](./technical-setup.md) for detailed implementation instructions or visit the [Architecture Documentation](./architecture.md) to understand the system design.

:::related-docs:::
